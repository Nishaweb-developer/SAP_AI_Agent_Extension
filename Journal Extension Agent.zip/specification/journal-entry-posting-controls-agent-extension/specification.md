# Specification: journal-entry-posting-controls-agent-extension

> **Guidelines**: Read [guidelines.md](../guidelines.md) and [guidelines-agent-extension.md](../guidelines-agent-extension.md) before executing ANY tasks below. Follow all constraints described there throughout execution.

## Basic Setup

- [x] Read `product-requirements-document.md` and `intent.md` to confirm the full requirements context
- [x] Confirm the base agent to extend:
  - Agent: Journal Entry Agent
  - ordId: `sap.agtjea:agent:journal-entry-agent:v1`
  - Version: `1.0.1`

## Feature Flag Check

- [x] Check feature flags before proceeding:
  - `enable_agent_extension_mcp_server` = `false` → **MCP tools are disabled; do NOT add any `tools` section to `extension.yaml`**
  - `enable_agent_extension_n8n_hooks` = `false` → **n8n hooks are disabled; do NOT add any `hooks` section to `extension.yaml`**
- [x] Proceed with **instructions only** — the agent supports `instructionSupported: true` and instructions do not require a feature flag

## Capability Scope (after reconciliation)

- Instructions: **Yes** — custom instructions enforce all three posting guardrails
- Tools: **No** — `enable_agent_extension_mcp_server` is `false`
- Hooks: **No** — `enable_agent_extension_n8n_hooks` is `false`

## Custom Instructions Content

The `extension.yaml` `instruction` field must encode all three guardrails. The instructions must direct the agent to:

### REQ-01 — Debit/Credit Balance Validation

- [x] Before attempting to post any journal entry, sum all debit line item amounts and all credit line item amounts
- [x] If the totals are not equal, **block posting** — do NOT call the post API
- [x] Inform the user of the exact imbalance, e.g.: "The entry cannot be posted: debits total [X] but credits total [Y]. The difference is [Z]. Please correct the line items and try again."
- [x] Log: `M1.achieved: debit/credit balance validated — entry is balanced` when balanced
- [x] Log: `M1.missed: entry is unbalanced — debits and credits do not match; posting blocked` when blocked

### REQ-02 — Mandatory Pre-Posting Simulation

- [x] After balance validation passes, always call the simulation step before presenting a posting confirmation to the user
- [x] Display the simulation result to the user in a clear, readable format
- [x] Only present the "confirm posting" question after the simulation result has been shown
- [x] If the simulation call fails, inform the user and do NOT proceed to posting
- [x] If the simulation returns errors or warnings, surface them clearly to the user before asking to confirm
- [x] Log: `M2.achieved: simulation completed and result presented to user` when simulation runs and result is shown
- [x] Log: `M2.missed: simulation step was skipped or failed — posting not confirmed` when simulation is skipped or fails

### REQ-03 — Mandatory Document Header Text

- [x] Before attempting to post any journal entry, verify that the document header text field is non-empty
- [x] If the document header text is missing or empty, **block posting** — do NOT call the post API
- [x] Prompt the user to provide a header text, e.g.: "A document header text is required for every journal entry. Please provide a short description for this entry."
- [x] Only proceed with balance validation and simulation after the header text has been confirmed
- [x] Log: `M3.achieved: document header text present — entry is audit-ready` when header text is present
- [x] Log: `M3.missed: document header text missing — posting blocked; user prompted to provide one` when blocked

## Guardrail Execution Order

- [x] Enforce the following sequence for every posting request:
  1. Check document header text → block and prompt if missing (REQ-03)
  2. Validate debit/credit balance → block and explain if unbalanced (REQ-01)
  3. Run simulation and show result (REQ-02)
  4. Present posting confirmation to user
  5. Post only after explicit user confirmation

## Extension File Generation

- [x] Invoke `setup-solution` skill from the solution root to create `solution.yaml` and register `assets/journal-entry-posting-controls-agent-extension/asset.yaml`
- [x] Invoke the `create-agent-extension` skill from `assets/journal-entry-posting-controls-agent-extension/` to generate `extension.yaml` and `asset.yaml`
- [x] Ensure `extension.yaml` contains:
  - `agent.ordId: sap.agtjea:agent:journal-entry-agent:v1`
  - `capabilityImplementations[0].capabilityId: default`
  - `capabilityImplementations[0].instruction:` — full text of all three guardrails in natural language
  - **No `tools` section** (feature flag disabled)
  - **No `hooks` section** (feature flag disabled)
- [x] Ensure `asset.yaml` contains:
  - `requires` entry with `kind: agent`, `ordId: sap.agtjea:agent:journal-entry-agent:v1`, `version: 1.0.1`

## Final Validation

- [x] `assets/journal-entry-posting-controls-agent-extension/extension.yaml` is well-formed YAML and matches the Extension Descriptor schema
- [x] `assets/journal-entry-posting-controls-agent-extension/asset.yaml` is well-formed YAML and includes the agent `requires` entry
- [x] `extension.yaml` contains NO `tools` section and NO `hooks` section
- [x] `extension.yaml` `instruction` field covers all three guardrails (header text, balance check, simulation gate) and their log statements
- [x] `solution.yaml` lists `./assets/journal-entry-posting-controls-agent-extension/asset.yaml`
